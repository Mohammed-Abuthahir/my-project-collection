import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import toast from "react-hot-toast";
import { BASE_URL } from "..";

const Signup = () => {
  const navigate = useNavigate();

  const [user, setUser] = useState({
    fullName: "",
    username: "",
    password: "",
    confirmPassword: "",
    gender: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post(
        `${BASE_URL}/api/v1/user/register`,
        user,
        {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );

      if (res.data.success) {
        toast.success(res.data.message);

        setUser({
          fullName: "",
          username: "",
          password: "",
          confirmPassword: "",
          gender: "",
        });

        navigate("/login");
      }
    } catch (error) {
      console.log(error);

      toast.error(
        error.response?.data?.message || "Something went wrong"
      );
    }
  };

  return (
    <div className="min-w-96 mx-auto">
      <div className="w-full p-6 rounded-lg shadow-md bg-gray-400 bg-opacity-10 backdrop-blur-md border border-gray-100">
        <h1 className="text-3xl font-bold text-center mb-5">
          Signup
        </h1>

        <form onSubmit={handleSubmit}>

          {/* Full Name */}

          <div className="mb-3">
            <label className="label">
              <span className="label-text">Full Name</span>
            </label>

            <input
              type="text"
              placeholder="Enter Full Name"
              className="input input-bordered w-full"
              value={user.fullName}
              onChange={(e) =>
                setUser({ ...user, fullName: e.target.value })
              }
            />
          </div>

          {/* Username */}

          <div className="mb-3">
            <label className="label">
              <span className="label-text">Username</span>
            </label>

            <input
              type="text"
              placeholder="Enter Username"
              className="input input-bordered w-full"
              value={user.username}
              onChange={(e) =>
                setUser({ ...user, username: e.target.value })
              }
            />
          </div>

          {/* Password */}

          <div className="mb-3">
            <label className="label">
              <span className="label-text">Password</span>
            </label>

            <input
              type="password"
              placeholder="Enter Password"
              className="input input-bordered w-full"
              value={user.password}
              onChange={(e) =>
                setUser({ ...user, password: e.target.value })
              }
            />
          </div>

          {/* Confirm Password */}

          <div className="mb-3">
            <label className="label">
              <span className="label-text">Confirm Password</span>
            </label>

            <input
              type="password"
              placeholder="Confirm Password"
              className="input input-bordered w-full"
              value={user.confirmPassword}
              onChange={(e) =>
                setUser({
                  ...user,
                  confirmPassword: e.target.value,
                })
              }
            />
          </div>

          {/* Gender */}

          <div className="flex gap-6 my-4">

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="gender"
                value="male"
                checked={user.gender === "male"}
                onChange={(e) =>
                  setUser({
                    ...user,
                    gender: e.target.value,
                  })
                }
                className="radio radio-primary"
              />
              Male
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="gender"
                value="female"
                checked={user.gender === "female"}
                onChange={(e) =>
                  setUser({
                    ...user,
                    gender: e.target.value,
                  })
                }
                className="radio radio-primary"
              />
              Female
            </label>

          </div>

          <p className="text-center my-3">
            Already have an account?{" "}
            <Link
              to="/login"
              className="text-blue-500 hover:underline"
            >
              Login
            </Link>
          </p>

          <button
            type="submit"
            className="btn btn-primary btn-block"
          >
            Signup
          </button>

        </form>
      </div>
    </div>
  );
};

export default Signup;