const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email : {
        type : String,
        required : true,
        Unique : true
    },
    password : {
        type : String,
        requied : true
    },
    role : {
        type : String,
        enum : ['user', 'admin'],
        default : 'user'
    },
    verified : {
        type : Boolean,
        default : false
    },
    wishlist: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product",
    },
  ],
});

module.exports = mongoose.model("User", userSchema);