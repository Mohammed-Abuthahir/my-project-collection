const Product = require("../model/Product");
const model = require("../utils/gemini");

const chatWithAI = async (req, res) => {
  try {
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({
        success: false,
        message: "Message is required",
      });
    }

    // Search products
    const products = await Product.find({
      $or: [
        {
          name: {
            $regex: message,
            $options: "i",
          },
        },
        {
          category: {
            $regex: message,
            $options: "i",
          },
        },
        {
          description: {
            $regex: message,
            $options: "i",
          },
        },
      ],
    }).limit(5);

    let productInfo = "";

    if (products.length > 0) {
      productInfo = products
        .map(
          (p) =>
            `
        Name: ${p.name}
        Category: ${p.category}
        Price: ₹${p.price}
        Description: ${p.description}
        `
                )
                .join("\n-----------------\n");
            } else {
            productInfo = "No matching products found.";
            }

            const prompt = `
        You are an AI shopping assistant for NextCart.

        Rules:
        - Be friendly.
        - Only recommend products from the provided list.
        - Never invent products.
        - Keep answers under 120 words.

        Available Products:

        ${productInfo}

        Customer Question:

        ${message}
        `;

    const result = await model.generateContent(prompt);

    const reply = result.response.text();

    res.json({
      success: true,
      reply,
      products,
    });
  } catch (error) {
    console.log(error);

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

module.exports = {
  chatWithAI,
};