const express = require('express');
const { getProducts, getProductById, createProduct, updateProduct, deleteProduct ,getProductsByCategory, 
  getUniqueCategories} = require('../controllers/productController');
const { protect } = require('../middleware/authMiddleware');
const { admin } = require('../middleware/adminMiddleware');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

const router = express.Router();

// all product
router.route('/').get(getProducts).post(protect, admin, upload.single('image'), createProduct);

// 2. Category specific routes 
// (Must be above /:id so Express doesn't confuse 'categories' for a product ID)
router.get("/categories", getUniqueCategories);
router.get("/category/:categoryName", getProductsByCategory);

// specific product
router.route('/:id').get(getProductById).put(protect, admin, upload.single('image'), updateProduct).delete(protect, admin, deleteProduct);

module.exports = router;