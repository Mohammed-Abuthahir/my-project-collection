const express = require("express");

const router = express.Router();

const {
  addToWishlist,
  removeFromWishlist,
  getWishlist,
} = require("../controllers/wishlistController");

const { protect } = require("../middleware/authMiddleware");

router.get("/", protect, getWishlist);

router.post("/:id", protect, addToWishlist);

router.delete("/:id", protect, removeFromWishlist);

module.exports = router;