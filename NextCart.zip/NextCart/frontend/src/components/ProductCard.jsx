import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { FaHeart } from "react-icons/fa";
import { WishlistContext } from "../context/WishlistContext";

import "../styles/product.css";

const ProductCard = ({ product }) => {

  const { wishlist, toggleWishlist } =
    useContext(WishlistContext);

  const isWishlisted = wishlist.some(
    (item) => item._id === product._id
  );

  return (
    <div className="product-card">

      <button
        className="wishlist-btn"
        onClick={() => toggleWishlist(product._id)}
      >
        <FaHeart
          color={isWishlisted ? "red" : "#bbb"}
        />
      </button>

      <img
        src={product.imageUrl}
        className="product-image"
        alt={product.name}
      />

      <div className="product-info">

        <h3>{product.name}</h3>

        <p className="price">
          ₹{product.price}
        </p>

        <Link
          className="btn"
          to={`/product/${product._id}`}
        >
          View Details
        </Link>

      </div>

    </div>
  );
};

export default ProductCard;