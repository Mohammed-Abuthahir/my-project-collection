import { useState, useRef, useEffect } from "react";
import "../styles/chatbot.css";

const ChatBot = () => {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const [messages, setMessages] = useState([
    {
      sender: "ai",
      text: "👋 Hi! I'm your NextCart AI assistant. Ask me anything about products.",
      products: [],
    },
  ]);

  const bottomRef = useRef();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages]);

  const sendMessage = async () => {
    if (!message.trim()) return;

    const userMessage = message;

    setMessages((prev) => [
      ...prev,
      {
        sender: "user",
        text: userMessage,
      },
    ]);

    setMessage("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage,
        }),
      });

      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          text: data.reply,
          products: data.products,
        },
      ]);
    } catch (err) {
      console.log(err);
    }

    setLoading(false);
  };

  return (
    <>
      <button
        className="chat-floating-btn"
        onClick={() => setOpen(!open)}
      >
        💬
      </button>

      {open && (
        <div className="chat-window">
          <div className="chat-header">
            <span>🤖 NextCart AI</span>

            <button
              className="close-btn"
              onClick={() => setOpen(false)}
            >
              ✖
            </button>
          </div>

          <div className="chat-body">
            {messages.map((msg, index) => (
              <div key={index}>
                <div
                  className={
                    msg.sender === "user"
                      ? "user-message"
                      : "ai-message"
                  }
                >
                  {msg.text}
                </div>

                {msg.products?.map((product) => (
                  <div
                    key={product._id}
                    className="chat-product-card"
                  >
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                    />

                    <div>
                      <h4>{product.name}</h4>

                      <p>₹{product.price}</p>
                    </div>
                  </div>
                ))}
              </div>
            ))}

            {loading && (
              <div className="typing">
                AI is typing...
              </div>
            )}

            <div ref={bottomRef}></div>
          </div>

          <div className="chat-footer">
            <input
              value={message}
              placeholder="Ask anything..."
              onChange={(e) =>
                setMessage(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  sendMessage();
                }
              }}
            />

            <button onClick={sendMessage}>
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatBot;