import { createContext, useEffect, useState, useContext } from "react";
import { AuthContext } from "./AuthContext"; // 1. Import your AuthContext

export const WishlistContext = createContext();

const WishlistProvider = ({ children }) => {
  const [wishlist, setWishlist] = useState([]);
  const { user } = useContext(AuthContext); // 2. Consume the user object directly from Auth

  // Extract token from user context if available, otherwise fallback to localStorage
  const token = user?.token || localStorage.getItem("token");

  useEffect(() => {
    if (token) {
      fetchWishlist();
    } else {
      setWishlist([]); // Clear wishlist if user logs out
    }
  }, [token]); // 3. Re-fetch automatically whenever authentication token status changes

  const fetchWishlist = async () => {
    if (!token) return;

    try {
      const res = await fetch("/api/wishlist", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setWishlist(data.wishlist || []);
      }
    } catch (err) {
      console.error("Error fetching wishlist:", err);
    }
  };

  const toggleWishlist = async (productId) => {
    // Now it uses the absolute source of truth from your auth context state!
    if (!token) {
      alert("Please login to manage your wishlist!");
      return;
    }

    const exists = wishlist.some(
      (item) => item._id === productId || item.product === productId || item.product?._id === productId
    );

    try {
      if (exists) {
        setWishlist((prev) =>
          prev.filter((item) => item._id !== productId && item.product?._id !== productId && item.product !== productId)
        );

        await fetch(`/api/wishlist/${productId}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      } else {
        const res = await fetch(`/api/wishlist/${productId}`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (res.ok) {
          fetchWishlist();
        }
      }
    } catch (err) {
      console.error("Error toggling wishlist:", err);
      fetchWishlist();
    }
  };

  return (
    <WishlistContext.Provider value={{ wishlist, toggleWishlist, fetchWishlist }}>
      {children}
    </WishlistContext.Provider>
  );
};

export default WishlistProvider;