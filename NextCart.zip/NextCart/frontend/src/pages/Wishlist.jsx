import { useContext } from "react";

import { WishlistContext } from "../context/WishlistContext";

import ProductCard from "../components/ProductCard";

const Wishlist = () => {

  const { wishlist } = useContext(WishlistContext);

  return (
    <div className="shop-container">
      <h1>My Wishlist ❤️</h1>
      { wishlist.length===0 ?
        <h2>No Products</h2> : <div className="product-grid">
          {
            wishlist.map((product)=>(
              <ProductCard
                key={product._id}
                product={product}
              />
            ))
          }
        </div> }
    </div>

  );

};

export default Wishlist;