import React, { useEffect, useState } from "react";
import ProductCard from "../components/ProductCard";
import ChatBot from "../components/ChatBot";

const Home = () => {
  const INITIAL_VISIBLE_PRODUCTS = 4;

  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState("");
  const [visibleProducts, setVisibleProducts] = useState(
    INITIAL_VISIBLE_PRODUCTS
  );

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);

        const res = await fetch(`/api/products?page=${page}&limit=8`);
        const data = await res.json();

        setProducts(data.products);
        setTotalPages(data.totalPages);

        // Reset Load More whenever page changes
        setVisibleProducts(INITIAL_VISIBLE_PRODUCTS);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [page]);

  // Sort Products
  const sortedProducts = [...products].sort((a, b) => {
    switch (sortBy) {
      case "priceLow":
        return a.price - b.price;

      case "priceHigh":
        return b.price - a.price;

      case "nameAZ":
        return a.name.localeCompare(b.name);

      case "nameZA":
        return b.name.localeCompare(a.name);

      case "newest":
        return new Date(b.createdAt) - new Date(a.createdAt);

      default:
        return 0;
    }
  });

  return (
    <>
      <div className="home-container">
        <div className="hero-banner">
          <h1>Welcome to NextCart</h1>
          <p>Discover the best products at unbeatable prices.</p>
        </div>

        <h2>Featured Products</h2>

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="category-select"
        >
          <option value="">Sort By</option>
          <option value="priceLow">Price: Low to High</option>
          <option value="priceHigh">Price: High to Low</option>
          <option value="nameAZ">Name: A - Z</option>
          <option value="nameZA">Name: Z - A</option>
          <option value="newest">Newest</option>
        </select>

        {loading ? (
          <div>Loading...</div>
        ) : (
          <>
            <div className="product-grid">
              {sortedProducts
                .slice(0, visibleProducts)
                .map((product) => (
                  <ProductCard
                    key={product._id}
                    product={product}
                  />
                ))}
            </div>

            {/* Load More Button */}
            {visibleProducts < sortedProducts.length && (
              <div
                style={{
                  textAlign: "center",
                  margin: "30px 0",
                }}
              >
                <button
                  className="load-more-btn"
                  onClick={() =>
                    setVisibleProducts(
                      (prev) =>
                        prev + INITIAL_VISIBLE_PRODUCTS
                    )
                  }
                >
                  Load More...
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Pagination */}
      <div className="pagination">
        <button
          disabled={page === 1}
          onClick={() => setPage(page - 1)}
        >
          Previous
        </button>

        {[...Array(totalPages)].map((_, index) => (
          <button
            key={index}
            className={page === index + 1 ? "active" : ""}
            onClick={() => setPage(index + 1)}
          >
            {index + 1}
          </button>
        ))}

        <button
          disabled={page === totalPages}
          onClick={() => setPage(page + 1)}
        >
          Next
        </button>
      </div>

      <ChatBot />
    </>
  );
};

export default Home;