import React, { useEffect, useState ,useRef} from 'react'
import { sidebarStyles,cn } from '../assets/dummyStyle'
import {AnimatePresence, motion, scale} from 'framer-motion';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ArrowDown, ArrowUp, HelpCircle, Home, LogOut, Menu, User,X } from 'lucide-react';


const MENU_ITEMS = [
    { text: "Dashboard", path: "/", icon: <Home size={20} /> },
    { text: "Income", path: "/income", icon: <ArrowUp size={20} /> },
    { text: "Expenses", path: "/expense", icon: <ArrowDown size={20} /> },
    { text: "Profile", path: "/profile", icon: <User size={20} /> },
  ];

const Sidebar = ({ user,sidebarcollapsed,setSidebarCollapsed}) => {

  const {pathname} = useLocation();
  const navigate = useNavigate();
  const sidebarRef = useRef(null);

  const [mobileOpen , setMobileOpen] = useState(false);
  const[activeHover, setActiveHover] = useState(null);

  const{name : username = "User", email = "user@example.com"} = user || {};
  const initial = username.charAt(0).toUpperCase();
  
  // check from overflow in mobile 
    useEffect(() => {
      document.body.style.overflow = mobileOpen ? "hidden" : "auto";
      return () => { document.body.style.overflow = "auto" };
    }, [mobileOpen]);

    // click outside sidebar get collapsed
    useEffect(() => {
      const handleClickOutside = (e) => {
        if (mobileOpen && sidebarRef.current && !sidebarRef.current.contains(e.target)) {
          setMobileOpen(false);
        }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [mobileOpen]);

    // to logout

    const handleLogout = () => {
      localStorage.removeItem("token");
      navigate("/login");
    }
    const toggleSidebar = () =>  setSidebarCollapsed((c) => !c);

    // a small component 
      const renderMenuItem = ({ text, path, icon }) => {
    const isActive = pathname === path;
    return (
      <motion.li key={text} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
        <Link
          to={path}
          className={cn(
            sidebarStyles.menuItem.base,
            isActive ? sidebarStyles.menuItem.active : sidebarStyles.menuItem.inactive,
            sidebarcollapsed ? sidebarStyles.menuItem.collapsed : sidebarStyles.menuItem.expanded
          )}
          onMouseEnter={() => setActiveHover(text)}
          onMouseLeave={() => setActiveHover(null)}
        >
          <span className={isActive ? sidebarStyles.menuIcon.active : sidebarStyles.menuIcon.inactive}>
            {icon}
          </span>
          {!sidebarcollapsed && (
            <motion.span initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
              {text}
            </motion.span>
          )}
          {activeHover === text && !isActive && !sidebarcollapsed && (
            <span className={sidebarStyles.activeIndicator}></span>
          )}
        </Link>
      </motion.li>
    );
  };
  return (
    <>
    <div>
      <motion.div ref={sidebarRef} className= {sidebarStyles.sidebarContainer.base}
      initial= {{x : -100, opacity : 0}} animate= {{
        x : 0,
        opacity : 1,
        width : sidebarcollapsed ? 80 : 256,
      }} transition= {{type : "spring", damping : 25}}>
        <div className={sidebarStyles.sidebarInner.base}>
          <button onClick={toggleSidebar} className={sidebarStyles.toggleButton.base}>
            <motion.div
              initial={{ rotate: 0 }}
              animate={{ rotate: sidebarcollapsed ? 0 : 180 }}
              transition={{ duration: 0.3 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"  strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points={sidebarcollapsed ? "9 18 15 12 9 6" : "15 18 9 12 15 6"}></polyline>
              </svg>
            </motion.div>

                <motion.div 
                  className="ml-3 overflow-hidden"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                ></motion.div>
          </button>
          <div className={cn(
            sidebarStyles.userProfileContainer.base,
            sidebarcollapsed ? sidebarStyles.userProfileContainer.collapsed :
            sidebarStyles.userProfileContainer.expanded,
          )}>
            <div className='flex items-center'>
              <div className={sidebarStyles.userInitials.base}>
                {initial} 
              </div>
              {!sidebarcollapsed && (
                    <motion.div
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      transition={{ duration: 0.2 }}
                      className="ml-3 overflow-hidden"
                    >
                      <h2 className="text-sm font-bold text-gray-800 truncate">
                        {user.name}
                      </h2>

                      <p className="text-sm font-medium text-gray-800 truncate max-w-[120]">
                        {email}
                      </p>
                    </motion.div>
                  )}
              </div>
            
          </div>
          <div className='flex-1 overflow-y-auto py-4 custom-scrollbar'>
            <ul className={sidebarStyles.menuList.base}>
              {MENU_ITEMS.map(renderMenuItem)}
            </ul>
           </div>
           <div className={cn(
            sidebarStyles.footerContainer.base,
            sidebarcollapsed ? sidebarStyles.footerContainer.collapsed :
            sidebarStyles.footerContainer.expanded,
           )}
           >
            <Link className={cn(
              sidebarStyles.footerLink.base,
              sidebarcollapsed && sidebarStyles.footerLink.collapsed,
            )} to="https://hexagondigitalservices.com/contact">
              <HelpCircle size = {20}  className='text-gray-500'/>
              {sidebarcollapsed && <span>Support</span>}
            </Link>
            <button onClick={handleLogout} className={cn(
              sidebarStyles.logoutButton.base,
              sidebarcollapsed && sidebarStyles.logoutButton.collapsed
            )}>
              <LogOut size = {20} className="text-gray-500"/>
              {sidebarcollapsed && <span>Logout</span>}
            </button>
           </div>
         </div> 
      </motion.div>

      <motion.button onClick={() => setMobileOpen((prev) => !prev)}
      className={sidebarStyles.mobileMenuButton}
      whileHover={{scale : 1.05}} whileTop = {{scale : 0.95}}>
        {mobileOpen ? <X size= {24}/> : <Menu size={24} />}
      </motion.button>
    </div>
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
              className={sidebarStyles.mobileOverlay}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div 
                className={sidebarStyles.mobileBackdrop}
                onClick={() => setMobileOpen(false)}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              />
              
              <motion.div
                ref={sidebarRef}
                className={sidebarStyles.mobileSidebar.base}
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                exit={{ x: "-100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
              >
                <div className='relative h-full flex flex-col'>
                  <div className={sidebarStyles.mobileHeader}>
                    <div className={sidebarStyles.mobileUserContainer}>
                      <div className={sidebarStyles.userInitials.base}>
                        {initial}
                      </div>
                      <div>
                        <h2 className='text-lg font-bold text-gray-800'>
                          {username}
                        </h2>
                        <p className='text-sm text-gray-500'>
                          {email}
                        </p>
                      </div>
                    </div>
                    <button onClick={() => setMobileOpen(false)} 
                      className={sidebarStyles.mobileCloseButton}>
                        <X size={24} className='text-gray-600'/>
                    </button>
                  </div>
                  <div className='flex-1 overflow-y-auto py-4'>
                     <ul className={sidebarStyles.mobileMenuList}>
                    {MENU_ITEMS.map(({ text, path, icon }) => (
                      <motion.li key={text} whileTap={{ scale: 0.98 }}>
                        <Link
                          to={path}
                          onClick={() => setMobileOpen(false)}
                          className={cn(
                            sidebarStyles.mobileMenuItem.base,
                            pathname === path 
                              ? sidebarStyles.mobileMenuItem.active 
                              : sidebarStyles.mobileMenuItem.inactive
                          )}
                        >
                          <span className={pathname === path ? sidebarStyles.menuIcon.active : sidebarStyles.menuIcon.inactive}>
                            {icon}
                          </span>
                          <span>{text}</span>
                        </Link>
                      </motion.li>
                    ))}
                    </ul>
                  </div>
                  <div className={sidebarStyles.mobileFooter}>
                    <Link onClick={() => setMobileOpen(false)} to="https://hexagondigitalservices.com/contact" className={sidebarStyles.mobileFooterLink}>
                      <HelpCircle size={20} className='text-gray-500'/>
                      <span>Support</span>
                    </Link>
                    <button onClick={handleLogout} className={sidebarStyles.mobileLogoutButton}>
                      <LogOut size={20} className='text-gray-500'/>
                        Logout
                    </button>
                  </div>
                </div>
              </motion.div>
              </motion.div>
        )}
      </AnimatePresence>
  </>
  )
}

export default Sidebar